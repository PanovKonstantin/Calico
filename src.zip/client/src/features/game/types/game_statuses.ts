type gameStatuses =
  | ""
  | "placing_projects"
  | "placing_tile"
  | "choosing_from_market"
  | "finished";
export default gameStatuses;
