import CellType from "./cell";

type BoardType = { [key: string]: CellType };

export default BoardType;
