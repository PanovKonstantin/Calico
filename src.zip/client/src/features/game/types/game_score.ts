type GameScore = {
  cats: number;
  projects: number;
  colors: number;
  total: number;
};
export default GameScore;
