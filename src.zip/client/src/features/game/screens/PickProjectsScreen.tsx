import React from 'react'

type Props = {}

const PickProjectsScreen = (props: Props) => {
  return (
    <div>PickProjectsScreen</div>
  )
}

export default PickProjectsScreen