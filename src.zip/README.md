# Calico.io

## Manual installation

### Server
Install all required node packages

```npm i```

Build the production app

```npm run build```

Start the application

```npm run start:prod```


### Client
Install all required node packages

```npm i```



```npm run build```

```npm install -g serve```

```serve -s build```


## Docker installation

```docker compose up```