export const oEvents = {
  roommates: 'roommates',
  room: 'room',
  state: 'state',
};

export const iEvents = {
  getRoom: 'getRoom',
  getRoommates: 'getRoommates',
  setRoom: 'setRoom',
};
