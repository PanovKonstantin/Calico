export abstract class Tile {}
